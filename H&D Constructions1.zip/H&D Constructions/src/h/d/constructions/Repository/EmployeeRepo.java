/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Repository;

import h.d.constructions.Employee.EmployeeAttributes;
import h.d.constructions.Databaseconnection.DatabaseConnection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tharindu
 */
public class EmployeeRepo {
    public void addEmployee(EmployeeAttributes emp) {
    try {

            DatabaseConnection DBConn = new DatabaseConnection();
            DBConn.init();
            Statement stmt = DBConn.getConnection().createStatement();

            String sql = "INSERT INTO EMPLOYEE ( EMPID ,EMPNIC ,EMPFNAME ,EMPLNAME ,EMPADDRESS ,EMPTELNO ,EMPPOSITION ,EMPBASICSALARY ) VALUES (  '" + emp.getEMPID()+ "',' " + emp.getEMPNIC() + "'," + emp.getEMPFNAME() + ",'" + emp.getEMPLNAME() + "','" + emp.getEMPADDRESS() + "','" + emp.getEMPTELNO() + "','" + emp.getEMPPOSITION() + "','" + emp.getEMPBASICSALARY() + "'";

            stmt.executeUpdate(sql);
            System.out.println("Inserted records into the table...");

        } catch (SQLException e) {

        }
}
    
    
}
