/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Repository;

import h.d.constructions.Construction.ConstructionAttributes;
import h.d.constructions.Databaseconnection.DatabaseConnection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tharindu
 */
public class ConstructionRepo {

    public void addConstruction(ConstructionAttributes cons) {
        try {

            DatabaseConnection DBConn = new DatabaseConnection();
            DBConn.init();
            Statement stmt = DBConn.getConnection().createStatement();

            String sql = "INSERT INTO construction (consid,consname,consprice,consaddress) VALUES (  '" + cons.getCONSID() + "',' " + cons.getCONSNAME() + "'," + cons.getCONSPRICE() + ",'" + cons.getCONSADDRESS() + "'";

            stmt.executeUpdate(sql);
            System.out.println("Inserted records into the table...");

        } catch (SQLException e) {

        }

    }
}
