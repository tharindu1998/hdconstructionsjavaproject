/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Repository;

import h.d.constructions.Customer.CustomerAttributes;
import h.d.constructions.Databaseconnection.DatabaseConnection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author tharindu
 */
public class CustomerRepo {
    public void addCustomer(CustomerAttributes cus) {
    try {

            DatabaseConnection DBConn = new DatabaseConnection();
            DBConn.init();
            Statement stmt = DBConn.getConnection().createStatement();

            String sql = "INSERT INTO CUSTOMER (cusid,cusfname,cuslname,cusaddress,custelno) VALUES (  '" + cus.getCUSID()+ "',' " + cus.getCUSFNAME() + "'," + cus.getCUSLNAME() + ",'" + cus.getCUSADDRESS() + "','" + cus.getCUSTELNO() + "'";

            stmt.executeUpdate(sql);
            System.out.println("Inserted records into the table...");

        } catch (SQLException e) {

        }
}
    
}
