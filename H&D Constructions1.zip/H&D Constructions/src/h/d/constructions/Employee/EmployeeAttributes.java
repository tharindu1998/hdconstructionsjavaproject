/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Employee;

/**
 *
 * @author tharindu
 */
public class EmployeeAttributes {
    String EMPID;
    String EMPTITLE;
    String EMPNIC;
    String EMPFNAME;
    String EMPLNAME;
    String EMPADDRESS;
    String EMPTELNO;
    String EMPPOSITION;
    String EMPBASICSALARY;

    public String getEMPID() {
        return EMPID;
    }

    public void setEMPID(String EMPID) {
        this.EMPID = EMPID;
    }

    public String getEMPTITLE() {
        return EMPTITLE;
    }

    public void setEMPTITLE(String EMPTITLE) {
        this.EMPTITLE = EMPTITLE;
    }

    public String getEMPNIC() {
        return EMPNIC;
    }

    public void setEMPNIC(String EMPNIC) {
        this.EMPNIC = EMPNIC;
    }

    public String getEMPFNAME() {
        return EMPFNAME;
    }

    public void setEMPFNAME(String EMPFNAME) {
        this.EMPFNAME = EMPFNAME;
    }

    public String getEMPLNAME() {
        return EMPLNAME;
    }

    public void setEMPLNAME(String EMPLNAME) {
        this.EMPLNAME = EMPLNAME;
    }

    public String getEMPADDRESS() {
        return EMPADDRESS;
    }

    public void setEMPADDRESS(String EMPADDRESS) {
        this.EMPADDRESS = EMPADDRESS;
    }

    public String getEMPTELNO() {
        return EMPTELNO;
    }

    public void setEMPTELNO(String EMPTELNO) {
        this.EMPTELNO = EMPTELNO;
    }

    public String getEMPPOSITION() {
        return EMPPOSITION;
    }

    public void setEMPPOSITION(String EMPPOSITION) {
        this.EMPPOSITION = EMPPOSITION;
    }

    public String getEMPBASICSALARY() {
        return EMPBASICSALARY;
    }

    public void setEMPBASICSALARY(String EMPBASICSALARY) {
        this.EMPBASICSALARY = EMPBASICSALARY;
    }
    
    
    
    
}
