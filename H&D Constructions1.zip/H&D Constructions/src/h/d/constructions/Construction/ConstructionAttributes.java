/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Construction;

/**
 *
 * @author tharindu
 */
public class ConstructionAttributes {
    String CONSID ;
    String CONSNAME ;
    int CONSPRICE ;
    String CONSADDRESS ;

    public String getCONSID() {
        return CONSID;
    }

    public void setCONSID(String CONSID) {
        this.CONSID = CONSID;
    }

    public String getCONSNAME() {
        return CONSNAME;
    }

    public void setCONSNAME(String CONSNAME) {
        this.CONSNAME = CONSNAME;
    }

    public int getCONSPRICE() {
        return CONSPRICE;
    }

    public void setCONSPRICE(int CONSPRICE) {
        this.CONSPRICE = CONSPRICE;
    }

    public String getCONSADDRESS() {
        return CONSADDRESS;
    }

    public void setCONSADDRESS(String CONSADDRESS) {
        this.CONSADDRESS = CONSADDRESS;
    }
    
    
    
    
    
}
