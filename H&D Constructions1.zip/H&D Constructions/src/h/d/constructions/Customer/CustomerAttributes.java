/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Customer;

/**
 *
 * @author tharindu
 */
public class CustomerAttributes {

    String CUSID;
    String CUSFNAME;
    String CUSLNAME;
    String CUSADDRESS;
    String CUSTELNO;
    String CUSTITLE;

    public String getCUSID() {
        return CUSID;
    }

    public void setCUSID(String CUSID) {
        this.CUSID = CUSID;
    }

    public String getCUSFNAME() {
        return CUSFNAME;
    }

    public void setCUSFNAME(String CUSFNAME) {
        this.CUSFNAME = CUSFNAME;
    }

    public String getCUSLNAME() {
        return CUSLNAME;
    }

    public void setCUSLNAME(String CUSLNAME) {
        this.CUSLNAME = CUSLNAME;
    }

    public String getCUSADDRESS() {
        return CUSADDRESS;
    }

    public void setCUSADDRESS(String CUSADDRESS) {
        this.CUSADDRESS = CUSADDRESS;
    }

    public String getCUSTELNO() {
        return CUSTELNO;
    }

    public void setCUSTELNO(String CUSTELNO) {
        this.CUSTELNO = CUSTELNO;
    }

    public String getCUSTITLE() {
        return CUSTITLE;
    }

    public void setCUSTITLE(String CUSTITLE) {
        this.CUSTITLE = CUSTITLE;
    }

}
