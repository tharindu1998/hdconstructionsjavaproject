/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Databaseconnection;
 

import java.sql.DriverManager;
import java.sql.Connection;

import java.sql.SQLException; 
import java.util.logging.Level;
import java.util.logging.Logger; 

/**
 *
 * @author tharindu
 */
 public class DatabaseConnection {
    // JDBC driver name and database URL 

    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:tcp://localhost/~/HDConstruction";
    //  Database credentials 
    static final String USER = "tharindu";
    static final String PASS = "tharindu";
    static Connection conn ;

    public   void init() throws SQLException {

        try {
            // STEP 1: Register JDBC driver
            Class.forName(JDBC_DRIVER);
            //STEP 2: Open a connection 
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public   Connection getConnection(){
        return conn;
    }
    
    
}
