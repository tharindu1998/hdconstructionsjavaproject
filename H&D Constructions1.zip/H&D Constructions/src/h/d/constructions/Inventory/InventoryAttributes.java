/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h.d.constructions.Inventory;

/**
 *
 * @author tharindu
 */
public class InventoryAttributes {
    String InventoryID;
    String Cost;
    int InventoryName;
    String Description;

    public String getInventoryID() {
        return InventoryID;
    }

    public void setInventoryID(String InventoryID) {
        this.InventoryID = InventoryID;
    }

    public String getInventoryCost() {
        return  Cost;
    }

    public void setInventoryCost(String InventoryCost) {
        this. Cost = InventoryCost;
    }

    public int getInventoryName() {
        return InventoryName;
    }

    public void setInventoryName(int InventoryName) {
        this.InventoryName = InventoryName;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getINVENTORYID() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
